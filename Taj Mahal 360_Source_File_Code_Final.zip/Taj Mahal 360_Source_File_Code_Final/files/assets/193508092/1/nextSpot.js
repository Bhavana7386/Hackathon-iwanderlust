var NextSpot = pc.createScript('nextSpot');

NextSpot.attributes.add('SHOW' , {type : 'entity'});
NextSpot.attributes.add('HIDE' , {type : 'entity'});

NextSpot.attributes.add('tx' , {type : 'number'});
NextSpot.attributes.add('ty' , {type : 'number'});

// initialize code called once per entity
NextSpot.prototype.initialize = function() {

    this.entity.button.on('click', function (event) {

    this.HIDE.enabled = false;
    this.SHOW.enabled = true;

    this.app.fire('changeParam', this.tx, this.ty);

}, this);

};