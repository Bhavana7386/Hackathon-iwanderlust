var Login = pc.createScript('login');

Login.attributes.add('css', {type: 'asset', assetType:'css', title: 'CSS Asset'});
Login.attributes.add('html', {type: 'asset', assetType:'html', title: 'HTML Asset'});

Login.attributes.add("blur", {type: "entity"});
Login.attributes.add("start", {type: "entity"});


Login.prototype.initialize = function () {
    var app = this.app;
    // create STYLE element

    var element = document.createElement("link");
    element.setAttribute("rel", "stylesheet");
    element.setAttribute("href", "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css");
    document.head.appendChild(element);
    
    var style = document.createElement('style');

    // append to head
    document.head.appendChild(style);
    style.innerHTML = this.css.resource || '';
    
    // Add the HTML
    var div = document.createElement('div');
    div.classList.add('center');
    div.innerHTML = this.html.resource || '';
    
    // append to body
    document.body.appendChild(div);
    
    // get button element by class
    var button = div.querySelector('button');

    var mStart = this.start;
    var mBlur = this.blur;

    // if found
    if (button) {
        
        button.addEventListener('click', function() {
        document.body.removeChild(div);

        mStart.enabled = true;
        mBlur.enabled = false;

        }, false);
    }
};