import json
import logging
import os
import sys
import time
import uuid
from dotenv import load_dotenv

import requests

load_dotenv()

logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,  # set to logging.DEBUG for verbose output
    format="[%(asctime)s] %(message)s",
    datefmt="%m/%d/%Y %I:%M:%S %p %Z",
)
logger = logging.getLogger(__name__)


SPEECH_ENDPOINT = os.getenv(    
    "SPEECH_ENDPOINT", "https://westus2.api.cognitive.microsoft.com"
    # "SPEECH_ENDPOINT", "https://southeastasia.api.cognitive.microsoft.com"
)

PASSWORDLESS_AUTHENTICATION = False
API_VERSION = "2024-04-15-preview"
SUBSCRIPTION_KEY = os.getenv("SUBSCRIPTION_KEY")

bot_text = "Now these tow identical buildings that you see on either sides are called as  Mihman Khana and Jilaukhana. \n\n Please click the camera icon on right side of the screen to click your picture at this sight."


def submit_synthesis(job_id: str):
    url = f"{SPEECH_ENDPOINT}/avatar/batchsyntheses/{job_id}?api-version={API_VERSION}"
    header = {"Content-Type": "application/json"}
    header.update({"Ocp-Apim-Subscription-Key": SUBSCRIPTION_KEY})
    isCustomized = False

    payload = {
        "synthesisConfig": {
            "voice": "en-IN-NeerjaNeural",
        },
        "customVoices": {
            # "YOUR_CUSTOM_VOICE_NAME": "YOUR_CUSTOM_VOICE_ID"
        },
        "inputKind": "plainText",
        "inputs": [
            {
                "content": bot_text,
            },
        ],
        "avatarConfig": (
            {
                "customized": isCustomized,
                "talkingAvatarCharacter": "Lori-graceful",
                "videoFormat": "mp4",
                "videoCodec": "h264",
                "subtitleType": "soft_embedded",
                "backgroundColor": "#000000FF",
            }
            if isCustomized
            else {
                "customized": isCustomized,
                "talkingAvatarCharacter": "Lori",
                "talkingAvatarStyle": "graceful",
                "videoFormat": "mp4",
                "videoCodec": "h264",
                "subtitleType": "soft_embedded",
                "backgroundColor": "#000000FF",
            }
        ),
    }

    response = requests.put(url, json.dumps(payload), headers=header)
    if response.status_code < 400:
        logger.info("Batch avatar synthesis job submitted successfully")
        logger.info(f'Job ID: {response.json()["id"]}')
        return True
    else:
        logger.error(
            f"Failed to submit batch avatar synthesis job: [{response.status_code}], {response.text}"
        )


def get_synthesis(job_id):
    url = f"{SPEECH_ENDPOINT}/avatar/batchsyntheses/{job_id}?api-version={API_VERSION}"
    header = {"Ocp-Apim-Subscription-Key": SUBSCRIPTION_KEY}

    response = requests.get(url, headers=header)
    if response.status_code < 400:
        logger.debug("Get batch synthesis job successfully")
        logger.debug(response.json())
        if response.json()["status"] == "Succeeded":
            logger.info(
                f'Batch synthesis job succeeded, download URL: {response.json()["outputs"]["result"]}'
            )
        return response.json()["status"]
    else:
        logger.error(f"Failed to get batch synthesis job: {response.text}")


def list_synthesis_jobs(skip: int = 0, max_page_size: int = 100):
    """List all batch synthesis jobs in the subscription"""
    url = f"{SPEECH_ENDPOINT}/avatar/batchsyntheses?api-version={API_VERSION}&skip={skip}&maxpagesize={max_page_size}"
    header = {"Ocp-Apim-Subscription-Key": SUBSCRIPTION_KEY}

    response = requests.get(url, headers=header)
    if response.status_code < 400:
        logger.info(
            f'List batch synthesis jobs successfully, got {len(response.json()["values"])} jobs'
        )
        logger.info(response.json())
    else:
        logger.error(f"Failed to list batch synthesis jobs: {response.text}")


if __name__ == "__main__":
    job_id = uuid.uuid4()
    if submit_synthesis(job_id):
        while True:
            status = get_synthesis(job_id)
            if status == "Succeeded":
                logger.info("batch avatar synthesis job succeeded")
                break
            elif status == "Failed":
                logger.error("batch avatar synthesis job failed")
                break
            else:
                logger.info(
                    f"batch avatar synthesis job is still running, status [{status}]"
                )
                time.sleep(5)
