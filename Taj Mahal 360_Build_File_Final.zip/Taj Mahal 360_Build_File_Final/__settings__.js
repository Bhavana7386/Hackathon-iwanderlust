window.ASSET_PREFIX = "";
window.SCRIPT_PREFIX = "";
window.SCENE_PATH = "2058622.json";
window.CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'deviceTypes': [`webgl2`, `webgl1`],
    'powerPreference': "default"
};
window.SCRIPTS = [ 193508092, 193508091, 193508108, 193508096, 193508098, 193855356, 193874636, 193998204, 194051104, 194059284, 194140422, 194345472, 194356603, 194363566, 194980771 ];
window.CONFIG_FILENAME = "config.json";
window.INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: true,
    useTouch: true
};
pc.script.legacy = false;
window.PRELOAD_MODULES = [
];
